'''
Создать (не программно) текстовый файл со следующим содержимым:
One — 1
Two — 2
Three — 3
Four — 4
Необходимо написать программу, открывающую файл на чтение
и считывающую построчно данные. При этом английские числительные должны заменяться на русские.
Новый блок строк должен записываться в новый текстовый файл.
'''

rus = {'One': 'Один', 'Two': 'Два', 'Three': 'Три', 'Four': 'Четыре'}
my_list_4 = []
with open('file_4.txt', 'r') as file_obj:
    for i in file_obj:
        i = i.split(' ', 1)
        my_list_4.append(rus[i[0]] + ' ' + i[1])
    print(my_list_4)

with open('file_4.txt', 'w') as file_obj_2:
    file_obj_2.writelines(my_list_4)
