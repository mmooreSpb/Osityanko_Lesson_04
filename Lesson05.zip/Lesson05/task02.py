'''
Создать текстовый файл, сохранить в нем несколько строк,
выполнить подсчет количества строк и количества слов в каждой строке.
'''

my_file = open('file.txt', 'r')
cont = my_file.read()
print(f'Содержимое файла: \n {cont}')
my_file = open('file.txt', 'r')
cont = my_file.readlines()
print(f'Количество строк в файле - {len(cont)}')
my_file = open('file.txt', 'r')
cont = my_file.readlines()
for el in range(len(cont)):
    print(f'Количество символов строки {el + 1} {len(cont)}')
my_file = open('file.txt', 'r')
cont = my_file.read()
cont = cont.split()
print(f'Общее количество слов - {len(cont)}')
my_file.close()
