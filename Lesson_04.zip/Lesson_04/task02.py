'''
Представлен список чисел. Необходимо вывести эл. исходного списка
значения которых больше предыдущего элемента.
'''

import random

first_list = random.sample(range(1, 500), 15)
print(first_list)
sec_list = []
for el in range(len(first_list) - 1):
    if first_list[el] < first_list[el + 1]:
        sec_list.append(first_list[el + 1])

print(sec_list)
