'''
Реализовать генератор с помощью функции с ключевым словом yield
создающим очередное значение.
При вызове функции должен создаваться обьект-генератор.
Функция должна вызываться: for el in fact(n)
'''

from itertools import count
from math import factorial


def fact():
    for el in count(1):
        yield factorial(el)


gen = fact()
n = 0
for elem in gen:
    if n < 6:
        print(elem)
    n += 1

# else:
#     break
